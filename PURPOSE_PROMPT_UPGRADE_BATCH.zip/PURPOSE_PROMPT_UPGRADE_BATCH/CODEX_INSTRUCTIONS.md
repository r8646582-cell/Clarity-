# PURPOSE — Coach/Companion Prompt Reliability Upgrade

Apply this batch to the repository root. The paths inside this ZIP mirror the repository paths.

## Goal
Upgrade PURPOSE's coaching/companion prompt layer without changing its product identity. Priorities are natural companionship, grounded coaching, uncertainty discipline, one canonical mutation protocol, deterministic time handling, and truthful execution receipts.

## Apply
1. Copy every `app/...` file in this batch over the file at the same repository-relative path.
2. Do not reintroduce `[[promise: ...]]` or `[[action: ...]]` into active coaching prompts. Old parser support may remain for backwards compatibility.
3. Do not change the canonical `<<<TOOL_CALL ...>>>` wire format unless all parser/tests are migrated together.
4. Run `./gradlew testDebugUnitTest`.
5. Run the existing smoke/test-bench workflow, especially promise create/edit/reschedule/failure scenarios and journey advancement.
6. If a test fails because it asserts old prompt wording rather than behavior, update that test to the new contract; do not weaken grounding/action guarantees.

## Non-negotiable invariants
- App state and execution receipts outrank assistant claims.
- A hidden action is a request, never evidence of success.
- Current user corrections outrank older memory.
- The model does not calculate epoch timestamps or calendar arithmetic.
- Promise edits mutate the existing promise; they do not create a duplicate.
- Reminders are created only when requested.
- No forced insight, commitment, journey advancement, or psychological explanation.
- Examples never become user facts.

## Verification scenarios
- Save a new promise after natural commitment; exactly one promise appears.
- Edit wording only; same promise ID, same due time.
- Edit due time only; same promise ID, wording remains correct.
- Edit wording + time; both update atomically from the user's perspective.
- At 00:30, `tonight 02:30` resolves to the intended late-night clock, not the next calendar night.
- Ambiguous promise target causes one clarification and no mutation.
- Failed edit produces a failed receipt and the next assistant turn does not claim success.
- Repeating an edit does not create a duplicate promise.
- `advance_journey` reports failure if nothing actually advanced.
- Listen-only does not manufacture advice or promises.
- Decision/journey/practice can finish without a promise when commitment is not earned.
