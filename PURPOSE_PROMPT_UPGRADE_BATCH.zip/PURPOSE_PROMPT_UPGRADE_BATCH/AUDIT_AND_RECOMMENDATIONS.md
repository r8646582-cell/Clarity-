# PURPOSE app audit — priority recommendations

## Included in this batch
1. Rebuilt the core persona around a strict evidence hierarchy and natural companion behavior.
2. Removed legacy promise syntax from active mode prompts and made TOOL_CALL the sole prompt-facing mutation protocol.
3. Removed model-side epoch/date arithmetic instructions.
4. Removed hard-coded biography from onboarding/persona so dynamic context remains authoritative.
5. Removed forced promises from Decision, Journey, and Practice modes.
6. Made Journey state-driven rather than assuming “yesterday”.
7. Tightened reflection against invented repetition and date conversion.
8. Added semantic prompt-contract regression tests.
9. Expanded prompt-editor validation so future edits cannot reintroduce legacy mutation/date instructions.
10. Fixed `advance_journey` false-positive receipts: success now requires an actual state transition.

## High-value next improvements (not silently changed in this batch)
### P0 — mutation receipts should be first-class structured state
`ActionReceiptStore` currently feeds the model a compact text string such as `edit_promise=failed:not_found`. Move toward a structured receipt object/JSON with action id, target id, requested values, persisted values, status, and failure reason. This makes retries and confirmations less ambiguous.

### P0 — add idempotency keys for model mutations
A network retry or regenerated answer can emit the same mutation twice. Give each action a request/action id and persist recently applied ids. Replaying the same id should return the original receipt instead of performing the mutation twice.

### P0 — transactional multi-field promise mutation
Keep edit wording, due time, and reminder movement in one repository transaction where possible. Tests should assert that a failure cannot leave title updated while time/reminder remains old.

### P1 — consume/acknowledge receipts explicitly
The current latest receipt is readable repeatedly until replaced/cleared. Add a receipt lifecycle (pending -> presented/acknowledged) or associate it with the exact assistant request generation so stale receipts cannot influence unrelated later turns.

### P1 — prompt precedence as code, not prose only
Keep the persona hierarchy, but also label injected blocks explicitly (`CURRENT_STATE`, `TIME_FACTS`, `MEMORY`, `EXAMPLES`) and ensure fresh state is always after cached memory. Add a test asserting ordering.

### P1 — test semantic outcomes, not exact prose
Critical tests should parse hidden actions and inspect database state: same ID after edit, no duplicate, exact due value, reminder movement, failure receipt, and no action under ambiguity. Avoid tests that reward a particular coaching sentence.

### P1 — companion-quality eval set
Add scored scenarios for: casual banter stays casual; pain without premature advice; correction accepted immediately; uncertainty stated without awkward disclaimers; no fake deep insight; challenge without shame; Roman Urdu naturalness; no repeated questions; no forced ending question.

### P2 — memory provenance
Store source session/message ids and evidence count for inferred patterns. A “likely” or “confirmed” pattern should be auditable back to evidence, reducing memory drift over months.

### P2 — prompt version telemetry
Record prompt hash/version with each AI request/reply. When a regression appears, you can identify exactly which prompt version produced it.

### P2 — legacy protocol retirement
Keep old marker/epoch parsing only while needed for existing stored replies. Once migration/backward-compatibility requirements expire, remove legacy parsing fields entirely to reduce attack surface and maintenance ambiguity.

## Visual/tree note
The leaf overlap issue is a rendering/layout concern rather than a prompt concern. Treat it separately with deterministic geometry/collision constraints and screenshot/golden tests across tree densities and screen sizes; do not try to solve it through AI prompting.
