#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="${1:-.}"
for top in app; do
  cp -R "$HERE/$top/." "$TARGET/$top/"
done
echo "PURPOSE prompt/reliability batch copied. Run: ./gradlew testDebugUnitTest"
