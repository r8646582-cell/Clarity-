package com.umair.purpose.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(
    entities = [
        Session::class, Message::class, Settings::class, UsageStat::class,
        ProfileEntry::class, Person::class, Note::class, Promise::class, AreaStatus::class, Letter::class,
        Quote::class, IdeaUsed::class, BehaviorEvent::class, Strength::class,
        Snapshot::class, OnboardingStep::class, Journey::class, Pulse::class, ErrorLog::class,
        PromptOverride::class, CustomJourney::class,
        // UPDATE-15 to 18
        Chapter::class, Milestone::class, Branch::class, JourneyAdjustment::class, UsageMonth::class, SearchDoc::class,
    ],
    version = 10,
    exportSchema = true,
)
abstract class PurposeDatabase : RoomDatabase() {
    /** Process-local coordination; no stored column or schema change. */
    val datasetWork = DatasetWork()
    abstract fun sessionDao(): SessionDao
    abstract fun messageDao(): MessageDao
    abstract fun settingsDao(): SettingsDao
    abstract fun usageDao(): UsageDao
    abstract fun profileDao(): ProfileDao
    abstract fun personDao(): PersonDao
    abstract fun noteDao(): NoteDao
    abstract fun promiseDao(): PromiseDao
    abstract fun areaDao(): AreaDao
    abstract fun letterDao(): LetterDao
    abstract fun quoteDao(): QuoteDao
    abstract fun ideaDao(): IdeaDao
    abstract fun behaviorDao(): BehaviorDao
    abstract fun strengthDao(): StrengthDao
    abstract fun snapshotDao(): SnapshotDao
    abstract fun onboardingDao(): OnboardingDao
    abstract fun journeyDao(): JourneyDao
    abstract fun pulseDao(): PulseDao
    abstract fun restoreDao(): RestoreDao
    abstract fun errorDao(): ErrorDao
    abstract fun forgetDao(): ForgetDao
    abstract fun promptDao(): PromptOverrideDao
    abstract fun customJourneyDao(): CustomJourneyDao
    abstract fun chapterDao(): ChapterDao
    abstract fun milestoneDao(): MilestoneDao
    abstract fun branchDao(): BranchDao
    abstract fun journeyAdjustmentDao(): JourneyAdjustmentDao
    abstract fun usageMonthDao(): UsageMonthDao
    abstract fun searchDao(): SearchDao

    companion object {
        /**
         * Every migration, oldest first. There is no destructive fallback anywhere, on purpose (UPDATE-15): a
         * missing or failing migration stops with an error and leaves his data exactly as it was.
         */
        val MIGRATIONS: Array<Migration> get() = Migrations.ALL

        /** Opens the SQLCipher-encrypted database. Schema changes need real migrations: this is his life's data. */
        fun open(context: Context, passphrase: ByteArray): PurposeDatabase {
            System.loadLibrary("sqlcipher")
            return Room.databaseBuilder(context, PurposeDatabase::class.java, "purpose.db")
                .openHelperFactory(SupportOpenHelperFactory(passphrase))
                .addMigrations(*MIGRATIONS)
                .build()
        }
    }
}
